面向开发者的文档


框架介绍

- 下载和运行
- 目录结构介绍
- `example`目录
- `src`目录（`js`目录，`less`目录）
- `package.json`
- `gulpfile.js`

如何提交 PR



上线

- 修改`package.json`版本
- 提交到github，并创建tag
- 提交到 npm
- 更新 .md 文档
- 文档同步到 kancloud
- ……

